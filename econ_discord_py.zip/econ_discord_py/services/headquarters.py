"""
Headquarters - Core data retrieval and update services
Equivalent to dataCrusher/Headquarters.js
"""

import discord
from sqlalchemy import select, and_
from sqlalchemy.orm import Session
from database.models import (
    Guilds, GuildMembers, DiscordUsers, Accounts, AccountType,
    Department, DepartmentMembers, TransactionLogs, Shift
)
from database.server import db_manager
from typing import Optional, List, Dict, Any
from decimal import Decimal
import logging

logger = logging.getLogger(__name__)


class RetrieveData:
    """Data retrieval service."""
    
    @staticmethod
    async def user(interaction: discord.Interaction, user_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve user data from database."""
        async with await db_manager.get_session() as session:
            try:
                stmt = select(GuildMembers).where(
                    and_(
                        GuildMembers.user == user_id,
                        GuildMembers.guild == str(interaction.guild_id)
                    )
                )
                result = await session.execute(stmt)
                user = result.scalar_one_or_none()
                
                if not user:
                    return None
                
                return {
                    "IDENT": user.IDENT,
                    "user": user.user,
                    "guild": user.guild,
                    "nickname": user.nickname,
                    "presence": user.presence
                }
            except Exception as e:
                logger.error(f"Error retrieving user: {e}")
                return None
    
    @staticmethod
    async def user_basic_accounts(
        interaction: discord.Interaction,
        member: discord.Member
    ) -> Optional[Dict[str, Any]]:
        """Retrieve user's basic wallet and bank accounts."""
        async with await db_manager.get_session() as session:
            try:
                # Get guild member
                stmt = select(GuildMembers).where(
                    and_(
                        GuildMembers.user == str(member.id),
                        GuildMembers.guild == str(interaction.guild_id)
                    )
                )
                result = await session.execute(stmt)
                guild_member = result.scalar_one_or_none()
                
                if not guild_member:
                    return None
                
                # Get wallet and bank accounts
                wallet_stmt = select(Accounts).where(
                    and_(
                        Accounts.owner == guild_member.IDENT,
                        Accounts.type == AccountType.PERSONAL_WALLET
                    )
                )
                bank_stmt = select(Accounts).where(
                    and_(
                        Accounts.owner == guild_member.IDENT,
                        Accounts.type == AccountType.PERSONAL_BANK
                    )
                )
                
                wallet = await session.execute(wallet_stmt)
                bank = await session.execute(bank_stmt)
                
                wallet_account = wallet.scalar_one_or_none()
                bank_account = bank.scalar_one_or_none()
                
                return {
                    "wallet": {
                        "IDENT": wallet_account.IDENT if wallet_account else None,
                        "balance": float(wallet_account.balance) if wallet_account else 0.0
                    },
                    "bank": {
                        "IDENT": bank_account.IDENT if bank_account else None,
                        "balance": float(bank_account.balance) if bank_account else 0.0
                    }
                }
            except Exception as e:
                logger.error(f"Error retrieving user accounts: {e}")
                return None
    
    @staticmethod
    async def treasury(guild_id: str, create_if_missing: bool = False) -> Optional[Dict[str, Any]]:
        """Retrieve guild treasury account."""
        async with await db_manager.get_session() as session:
            try:
                stmt = select(Guilds).where(Guilds.IDENT == guild_id)
                result = await session.execute(stmt)
                guild = result.scalar_one_or_none()
                
                if not guild:
                    return None
                
                return {
                    "IDENT": guild.IDENT,
                    "balance": float(guild.balance)
                }
            except Exception as e:
                logger.error(f"Error retrieving treasury: {e}")
                return None


class CreateData:
    """Data creation service."""
    
    @staticmethod
    async def new_account(
        guild_id: str,
        owner_id: str,
        account_type: AccountType,
        balance: Decimal = Decimal("0.0"),
        name: Optional[str] = None
    ) -> Optional[str]:
        """Create a new account."""
        async with await db_manager.get_session() as session:
            try:
                account = Accounts(
                    guild=guild_id,
                    owner=owner_id,
                    balance=balance,
                    type=account_type,
                    name=name
                )
                session.add(account)
                await session.commit()
                
                return account.IDENT
            except Exception as e:
                logger.error(f"Error creating account: {e}")
                await session.rollback()
                return None
    
    @staticmethod
    async def new_guild_member(
        guild_id: str,
        user_id: str,
        nickname: Optional[str] = None
    ) -> Optional[str]:
        """Create a new guild member."""
        async with await db_manager.get_session() as session:
            try:
                # Create user if doesn't exist
                discord_user = await session.execute(
                    select(DiscordUsers).where(DiscordUsers.IDENT == user_id)
                )
                if not discord_user.scalar_one_or_none():
                    user = DiscordUsers(IDENT=user_id, username=str(user_id))
                    session.add(user)
                
                # Create guild member
                guild_member = GuildMembers(
                    guild=guild_id,
                    user=user_id,
                    nickname=nickname
                )
                session.add(guild_member)
                await session.commit()
                
                return guild_member.IDENT
            except Exception as e:
                logger.error(f"Error creating guild member: {e}")
                await session.rollback()
                return None


class UpdateData:
    """Data update service."""
    
    @staticmethod
    async def account_balance(
        account_id: str,
        new_balance: Decimal,
        transaction_type: str = "manual",
        description: Optional[str] = None
    ) -> bool:
        """Update account balance."""
        async with await db_manager.get_session() as session:
            try:
                # Update account
                account = await session.get(Accounts, account_id)
                if not account:
                    return False
                
                old_balance = account.balance
                account.balance = new_balance
                
                # Log transaction
                log = TransactionLogs(
                    account=account_id,
                    amount=new_balance - old_balance,
                    transaction_type=transaction_type,
                    description=description
                )
                session.add(log)
                await session.commit()
                
                return True
            except Exception as e:
                logger.error(f"Error updating account balance: {e}")
                await session.rollback()
                return False
    
    @staticmethod
    async def treasury_balance(guild_id: str, new_balance: Decimal) -> bool:
        """Update guild treasury balance."""
        async with await db_manager.get_session() as session:
            try:
                guild = await session.get(Guilds, guild_id)
                if not guild:
                    return False
                
                guild.balance = new_balance
                await session.commit()
                
                return True
            except Exception as e:
                logger.error(f"Error updating treasury balance: {e}")
                await session.rollback()
                return False
    
    @staticmethod
    async def inactivate_member(guild_id: str, member_id: str) -> bool:
        """Inactivate a guild member."""
        async with await db_manager.get_session() as session:
            try:
                stmt = select(GuildMembers).where(
                    and_(
                        GuildMembers.IDENT == member_id,
                        GuildMembers.guild == guild_id
                    )
                )
                result = await session.execute(stmt)
                member = result.scalar_one_or_none()
                
                if member:
                    member.presence = "INACTIVE"
                    await session.commit()
                    return True
                
                return False
            except Exception as e:
                logger.error(f"Error inactivating member: {e}")
                await session.rollback()
                return False
    
    @staticmethod
    async def delete_server(guild_id: str) -> bool:
        """Delete all server data."""
        async with await db_manager.get_session() as session:
            try:
                guild = await session.get(Guilds, guild_id)
                if guild:
                    await session.delete(guild)
                    await session.commit()
                    return True
                return False
            except Exception as e:
                logger.error(f"Error deleting server: {e}")
                await session.rollback()
                return False


class GuildHQ:
    """Guild headquarters - guild-specific operations."""
    
    def __init__(self, interaction: discord.Interaction):
        """Initialize with interaction context."""
        self.interaction = interaction
        self.guild_id = str(interaction.guild_id)
    
    async def format_money(self, amount: Decimal, symbol: str = "$") -> str:
        """Format money with proper decimal places and symbol."""
        return f"{symbol}{float(amount):,.2f}"
    
    async def get_premium_status(self) -> bool:
        """Check if guild has premium subscription."""
        # This would check Discord entitlements
        # Implementation depends on bot subscription SKU setup
        return False
    
    async def get_guild_data(self) -> Optional[Dict[str, Any]]:
        """Get full guild data."""
        async with await db_manager.get_session() as session:
            try:
                guild = await session.get(Guilds, self.guild_id)
                if not guild:
                    return None
                
                return {
                    "IDENT": guild.IDENT,
                    "balance": float(guild.balance),
                    "logging_channel": guild.logging_channel
                }
            except Exception as e:
                logger.error(f"Error getting guild data: {e}")
                return None
