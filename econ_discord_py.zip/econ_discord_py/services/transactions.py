"""
Transaction Services
Handle money transfers, deposits, withdrawals
"""

from decimal import Decimal
from sqlalchemy import select, and_
from database.models import Accounts, TransactionLogs, AdvTransactionLogs
from database.server import db_manager
from typing import Optional, Tuple
import logging

logger = logging.getLogger(__name__)


class TransactionService:
    """Handle transaction operations."""
    
    @staticmethod
    async def transfer_money(
        from_account_id: str,
        to_account_id: str,
        amount: Decimal,
        description: Optional[str] = None
    ) -> Tuple[bool, Optional[str]]:
        """
        Transfer money between accounts.
        
        Returns:
            (success, error_message)
        """
        async with await db_manager.get_session() as session:
            try:
                # Get both accounts
                from_account = await session.get(Accounts, from_account_id)
                to_account = await session.get(Accounts, to_account_id)
                
                if not from_account:
                    return False, "Source account not found"
                if not to_account:
                    return False, "Destination account not found"
                
                # Check balance
                if from_account.balance < amount:
                    return False, f"Insufficient funds. Balance: ${float(from_account.balance):,.2f}"
                
                # Check amount
                if amount <= 0:
                    return False, "Transfer amount must be positive"
                
                # Perform transfer
                from_account.balance -= amount
                to_account.balance += amount
                
                # Create transaction logs
                from_log = TransactionLogs(
                    account=from_account_id,
                    amount=-amount,
                    transaction_type="transfer_out",
                    description=description or f"Transfer to {to_account.name}"
                )
                
                to_log = TransactionLogs(
                    account=to_account_id,
                    amount=amount,
                    transaction_type="transfer_in",
                    description=description or f"Transfer from {from_account.name}"
                )
                
                session.add(from_log)
                session.add(to_log)
                
                await session.commit()
                
                logger.info(
                    f"Transfer: {from_account_id} -> {to_account_id}: ${float(amount):,.2f}"
                )
                return True, None
            
            except Exception as e:
                logger.error(f"Transfer failed: {e}")
                await session.rollback()
                return False, f"Transaction failed: {str(e)}"
    
    @staticmethod
    async def deposit(
        account_id: str,
        amount: Decimal,
        source: str = "manual"
    ) -> Tuple[bool, Optional[str]]:
        """
        Deposit money into an account.
        
        Returns:
            (success, error_message)
        """
        async with await db_manager.get_session() as session:
            try:
                account = await session.get(Accounts, account_id)
                
                if not account:
                    return False, "Account not found"
                
                if amount <= 0:
                    return False, "Deposit amount must be positive"
                
                account.balance += amount
                
                log = TransactionLogs(
                    account=account_id,
                    amount=amount,
                    transaction_type="deposit",
                    description=f"Deposit from {source}"
                )
                session.add(log)
                
                await session.commit()
                
                return True, None
            
            except Exception as e:
                logger.error(f"Deposit failed: {e}")
                await session.rollback()
                return False, str(e)
    
    @staticmethod
    async def withdraw(
        account_id: str,
        amount: Decimal,
        destination: str = "manual"
    ) -> Tuple[bool, Optional[str]]:
        """
        Withdraw money from an account.
        
        Returns:
            (success, error_message)
        """
        async with await db_manager.get_session() as session:
            try:
                account = await session.get(Accounts, account_id)
                
                if not account:
                    return False, "Account not found"
                
                if amount <= 0:
                    return False, "Withdrawal amount must be positive"
                
                if account.balance < amount:
                    return False, f"Insufficient funds. Balance: ${float(account.balance):,.2f}"
                
                account.balance -= amount
                
                log = TransactionLogs(
                    account=account_id,
                    amount=-amount,
                    transaction_type="withdrawal",
                    description=f"Withdrawal to {destination}"
                )
                session.add(log)
                
                await session.commit()
                
                return True, None
            
            except Exception as e:
                logger.error(f"Withdrawal failed: {e}")
                await session.rollback()
                return False, str(e)
    
    @staticmethod
    async def get_transaction_history(
        account_id: str,
        limit: int = 10
    ) -> list:
        """Get recent transactions for an account."""
        async with await db_manager.get_session() as session:
            try:
                stmt = select(TransactionLogs).where(
                    TransactionLogs.account == account_id
                ).order_by(
                    TransactionLogs.timestamp.desc()
                ).limit(limit)
                
                result = await session.execute(stmt)
                transactions = result.scalars().all()
                
                return [
                    {
                        "IDENT": t.IDENT,
                        "amount": float(t.amount),
                        "type": t.transaction_type,
                        "description": t.description,
                        "timestamp": t.timestamp
                    }
                    for t in transactions
                ]
            
            except Exception as e:
                logger.error(f"Error retrieving transaction history: {e}")
                return []


class PaymentService:
    """Handle payment operations."""
    
    @staticmethod
    async def process_payment(
        payer_account_id: str,
        payee_account_id: str,
        amount: Decimal,
        payment_type: str,
        description: Optional[str] = None
    ) -> Tuple[bool, Optional[str]]:
        """
        Process a payment transaction.
        
        Args:
            payer_account_id: Account paying the money
            payee_account_id: Account receiving the money
            amount: Amount to transfer
            payment_type: Type of payment (salary, bonus, tax, etc.)
            description: Optional description
        
        Returns:
            (success, error_message)
        """
        return await TransactionService.transfer_money(
            payer_account_id,
            payee_account_id,
            amount,
            description or f"{payment_type} payment"
        )
    
    @staticmethod
    async def process_bulk_payment(
        payments: list,
        description: Optional[str] = None
    ) -> dict:
        """
        Process multiple payments at once.
        
        Args:
            payments: List of tuples (payer_id, payee_id, amount)
            description: Optional description
        
        Returns:
            {
                'total_processed': int,
                'total_amount': Decimal,
                'failed': list,
                'errors': dict
            }
        """
        results = {
            'total_processed': 0,
            'total_amount': Decimal('0.0'),
            'failed': [],
            'errors': {}
        }
        
        for payer_id, payee_id, amount in payments:
            success, error = await TransactionService.transfer_money(
                payer_id,
                payee_id,
                amount,
                description
            )
            
            if success:
                results['total_processed'] += 1
                results['total_amount'] += amount
            else:
                results['failed'].append((payer_id, payee_id, amount))
                results['errors'][f"{payer_id}->{payee_id}"] = error
        
        return results
